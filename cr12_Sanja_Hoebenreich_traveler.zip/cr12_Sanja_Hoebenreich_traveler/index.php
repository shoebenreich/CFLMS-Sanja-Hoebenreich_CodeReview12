<!DOCTYPE html>
<html>
 <head>
   <meta charset="<?php bloginfo('charset'); ?>">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   
   <meta name="description" content="<?php bloginfo('description'); ?>">
   <title><?php bloginfo('name'); ?></title>
   <?php wp_head(); ?>
 </head>
<body class="bg-light">
    <?php get_header(); ?> 
   <h2 class="text-center redrose my-3">Our Blogposts:</h2>
   <div class="container">
   <div class="card-deck mb-5">

<?php if(have_posts()) : ?>

<?php while(have_posts()) : the_post(); ?>

<div class="card">
    <div class="card-body bg-light">
      <a href="<?php the_permalink(); ?>"><h5 class="card-title"><?php the_title(); ?></h5></a>
      <p class="text-danger"><?php the_excerpt(); ?></p>
      <p class="card-text"><small class="text-muted">By <?php the_author(); ?>, <?php the_time('F j, Y G:i'); ?></small></p>
    </div>
  </div>

<?php endwhile; ?>

<?php else :?>

<p>No posts found</p>
<?php endif; ?>
</div>
</div>
<div class="widgets w-25 mx-auto">
<?php
      if(is_active_sidebar('sidebar')):
     dynamic_sidebar('sidebar');
     endif;  
?>
</div>

<?php wp_footer(); ?>
<?php get_footer(); ?>
</body>
</html>