<footer class="footer fixed-bottom bg-dark">
      <div class="container-fluid text-center py-2 text-muted">
&copy; 2020 <br> Sanja Höbenreich
      </div>
    </footer>