<!DOCTYPE html>
<html>
 <head>
   <meta charset="<?php bloginfo('charset'); ?>">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   
   <meta name="description" content="<?php bloginfo('description'); ?>">
   <title><?php bloginfo('name'); ?></title>
   <?php wp_head(); ?>
 </head>
<body class="bg-light">
<?php wp_head(); ?>
<?php get_header(); ?>   
<div class="container">
 

       <?php if(have_posts()) : ?>

       <?php while(have_posts()) : the_post(); ?>
       
            <h2 class="text-center text-dark mt-5 redrose"><?php the_title(); ?></h2>

            <p class="text-right redrose"><?php the_author() ?>, <?php the_time('j. F Y G:i'); ?></p>
            
            <?php the_content(); ?>

        <?php endwhile; ?>

       <?php else :?>

            <p>No posts found</p>

        <?php endif; ?>
   </div>


 <?php get_footer(); ?>

</body>
</html>
