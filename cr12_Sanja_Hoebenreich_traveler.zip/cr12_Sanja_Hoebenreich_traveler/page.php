<!DOCTYPE html>
<html>
 <head>
   <meta charset="<?php bloginfo('charset'); ?>">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   
   <meta name="description" content="<?php bloginfo('description'); ?>">
   <title><?php bloginfo('name'); ?></title>
   <?php wp_head(); ?>
 </head>
<body class="bg-light">
<?php get_header(); ?>


<?php wp_footer(); ?>
<?php get_footer(); ?>
</body>
</html>